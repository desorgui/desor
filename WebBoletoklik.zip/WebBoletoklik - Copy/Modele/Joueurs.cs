﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Modele
{
    public class Joueurs
    {
        #region Les attributs
        private Int64 Id;
        private string Nomcomplet;
        private string sexe;
        private DateTime dateajout;
        private string username;
        #endregion

        #region Les proprietes
        public Int64 ID
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }
        public string NomComplet
        {
            get
            {
                return Nomcomplet;
            }
            set
            {
                if (Regex.IsMatch(value, "^[A-Za-z][a-zA-Z '\\-]+$"))
                {
                    Nomcomplet = value;
                }
                else
                {
                    throw new Exception("Le nom saisi est incorrect!");
                }

            }
        }
        public string Sexe
        {
            get
            {
                return sexe;
            }
            set
            {
                if (value.Equals("Masculin") || value.Equals("Feminin"))
                {
                    sexe = value;
                }
                else
                {
                    throw new Exception("La valeur de sexe est incorrecte /n Valeur attendu (Masculin , Feminin)");
                }
            }
        }
        public DateTime Dateajout
        {
            get
            {
                return dateajout;
            }
            set
            {
                dateajout = value;
            }
        }
        public string UserName
        {
            get
            {
                return username;
            }
            set
            {
                if (Regex.IsMatch(value, "^[A-Za-z][a-zA-Z '\\-]+$"))
                {
                    username = value;
                }
                else
                {
                    throw new Exception("Le nom saisi est incorrect!");
                }

            }
        }
        #endregion

        #region Les Constructeurs
        public Joueurs()
        {
            this.dateajout = DateTime.Now;
        }
        #endregion

        #region Les Methodes utiles
        public override string ToString()
        {
            return username;
        }


        public override bool Equals(object obj)
        {
            Joueurs jo = null;
            try
            {
                jo = (Joueurs)obj;
            }
            catch (Exception)
            {


            }
            return this.Id.Equals(jo.Id);
        }
        #endregion
    }
}
