﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Modele
{
    public class Jeux
    {
        #region Les attributs
        private Int64 Id;
        private string Description;
        private DateTime DateJeu;
        private Int32 lot1;
        private Int32 lot2;
        private Int32 lot3;
        private Boolean Estactif = true;
        #endregion

        #region Les proprietes
        public Int64 ID
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }
        public string description
        {
            get
            {
                return Description;
            }
            set
            {
                if (Regex.IsMatch(value, "^[A-Za-z][a-zA-Z '\\-]+$"))
                {
                    Description = value;
                }
                else
                {
                    throw new Exception("");
                }

            }
        }
        public DateTime datejeu
        {
            get
            {
                return DateJeu;
            }
            set
            {

                DateJeu = value;
            }
        }
        public Int32 Lot1
        {
            get
            {
                return lot1;
            }
            set
            {
                lot1 = value;
            }
        }
        public Int32 Lot2
        {
            get
            {
                return lot2;
            }
            set
            {
                lot2 = value;
            }
        }
        public Int32 Lot3
        {
            get
            {
                return lot3;
            }
            set
            {
                lot3 = value;
            }
        }
        public bool estactif
        {
            get
            {
                return Estactif;
            }
            set
            {
                Estactif = value;
            }
        }
        #endregion

        #region Les Constructeurs
        public Jeux()
        {
            this.datejeu = DateTime.Now;
        }
        #endregion

        #region Les Methodes utiles
        public override string ToString()
        {
            return Description;
        }
        public override bool Equals(object obj)
        {
            Jeux je = null;
            try
            {
                je = (Jeux)obj;
            }
            catch (Exception)
            {


            }
            return this.Id.Equals(je.Id);
        }
        #endregion
    }
}
