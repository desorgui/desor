﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Modele
{
    public class Boule
    {

        #region Les attributs
        private Int64 Id;
        private Int64 IdJoeur;
        private Int64 IdJeux;
        private int Numero;
        private decimal Prix;
        private DateTime DateMise;
        #endregion

        #region Les proprietes
        public Int64 ID
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }
        public Int64 idjoeur
        {
            get
            {
                return IdJoeur;
            }
            set
            {
                IdJoeur = value;
            }
        }
        public Int64 idjeux
        {
            get
            {
                return IdJeux;
            }
            set
            {
                IdJeux = value;
            }
        }
        public int numero
        {
            get
            {
                return Numero;
            }
            set
            {
                Numero = value;
            }
        }
        public decimal prix
        {
            get
            {
                return Prix;
            }
            set
            {
                Prix = value;

            }
        }
        public DateTime datemise
        {
            get
            {
                return DateMise;
            }
            set
            {
                DateMise = value;
            }
        }

        #endregion

        #region Les Constructeurs
        public Boule()
        {
            this.DateMise = DateTime.Now;
        }
        #endregion

        #region Les Methodes utiles
        //public override string ToString()
        //{
        //    return Nomcomplet;
        //}
        //public override bool Equals(object obj)
        //{
        //    Joueurs jo = null;
        //    try
        //    {
        //        jo = (Joueurs)obj;
        //    }
        //    catch (Exception)
        //    {


        //    }
        //    return this.Id.Equals(jo.Id);
        //}
        //public override string ToString()
        //{
        //    return username;
        //}
        #endregion
    }
}
