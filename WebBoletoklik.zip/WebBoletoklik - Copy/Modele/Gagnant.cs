﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Modele
{
    public class Gagnant
    {

        #region Les attributs
        private Int64 Id;
        private Int64 IdJoeur;
        private Int64 IdJeux;
        private decimal Montant;
        private DateTime DateGain;
        #endregion

        #region Les proprietes
        public Int64 ID
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }
        public Int64 idjoeur
        {
            get
            {
                return IdJoeur;
            }
            set
            {
                IdJoeur = value;
            }
        }
        public Int64 idjeux
        {
            get
            {
                return IdJeux;
            }
            set
            {
                IdJeux = value;
            }
        }
        public decimal montant
        {
            get
            {
                return Montant;
            }
            set
            {
                Montant = value;

            }
        }
        public DateTime dateGain
        {
            get
            {
                return DateGain;
            }
            set
            {
                DateGain = value;
            }
        }

        #endregion

        #region Les Constructeurs
        public Gagnant()
        {
            this.DateGain = DateTime.Now;
        }
        #endregion

        #region Les Methodes utiles
        //public override string ToString()
        //{
        //    return Nomcomplet;
        //}
        //public override bool Equals(object obj)
        //{
        //    Joueurs jo = null;
        //    try
        //    {
        //        jo = (Joueurs)obj;
        //    }
        //    catch (Exception)
        //    {


        //    }
        //    return this.Id.Equals(jo.Id);
        //}
        //public override string ToString()
        //{
        //    return username;
        //}
        #endregion
    }
}
