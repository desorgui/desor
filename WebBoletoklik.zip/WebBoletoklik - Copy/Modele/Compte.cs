﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Modele
{
    public class Compte
    {
        #region Les attributs
        private Int64 Id;
        private Int64 IdJoeur;
        private decimal Montant;
        private DateTime DateModification;
        #endregion

        #region Les proprietes
        public Int64 ID
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }
        public Int64 idjoeur
        {
            get
            {
                return IdJoeur;
            }
            set
            {
                IdJoeur = value;
            }
        }
        public decimal montant
        {
            get
            {
                return Montant;
            }
            set
            {
                Montant = value;

            }
        }
        public DateTime dateModification
        {
            get
            {
                return DateModification;
            }
            set
            {
                DateModification = value;
            }
        }

        #endregion

        #region Les Constructeurs
        public Compte()
        {
            this.DateModification = DateTime.Now;
        }
        #endregion

        #region Les Methodes utiles
        //public override string ToString()
        //{
        //    return Nomcomplet;
        //}
        //public override bool Equals(object obj)
        //{
        //    Joueurs jo = null;
        //    try
        //    {
        //        jo = (Joueurs)obj;
        //    }
        //    catch (Exception)
        //    {


        //    }
        //    return this.Id.Equals(jo.Id);
        //}
        //public override string ToString()
        //{
        //    return username;
        //}
        #endregion
    }
}
