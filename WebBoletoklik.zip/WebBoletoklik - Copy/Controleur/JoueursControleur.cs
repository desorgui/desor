﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
// importer projet modele
using Modele;

namespace Controleur
{
    public class JoueurControleur
    {

        static string chcon = "Data Source=.;Initial Catalog=BDBoletoKlik;Integrated Security=True";
        //toutes les methodes de modification doivent retourner un entier


        #region les fonction de modifications


        public static int Add(Int64 id, string NomComplet, string Sexe, DateTime DateAjout, string Username)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "insert into Joueurs (Id,NomComplet,Sexe,DateAjout,Username) values (@id,@nc,@s,@Da,@un)";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Joueurs Jo = new Joueurs();
                Jo.ID = id;
                Jo.NomComplet = NomComplet;
                Jo.Sexe = Sexe;
                Jo.Dateajout = DateAjout;
                Jo.UserName = Username;
                //definir les parametres
                cmd.Parameters.AddWithValue("@id", Jo.ID);
                cmd.Parameters.AddWithValue("@nc", Jo.NomComplet);
                cmd.Parameters.AddWithValue("@s", Jo.Sexe);
                cmd.Parameters.AddWithValue("@Da", Jo.Dateajout);
                cmd.Parameters.AddWithValue("@un", Jo.UserName);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }




        public static int Update(string NomComplet, string Sexe, string Username)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "update Joueurs set NomComplet=@nc,sexe=@s where UserName=@us";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Joueurs Jo = new Joueurs();
                Jo.UserName = Username;
                Jo.NomComplet = NomComplet;
                Jo.Sexe = Sexe;
                //definir les parametres
                cmd.Parameters.AddWithValue("@tel", Jo.UserName);
                cmd.Parameters.AddWithValue("@nc", Jo.NomComplet);
                cmd.Parameters.AddWithValue("@s", Jo.Sexe);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //        throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }




        public static int Delete(string username)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "delete from Joueurs where UserName=@us";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Joueurs Jo = new Joueurs();
                Jo.UserName = username;


                //definir les parametres
                cmd.Parameters.AddWithValue("@us", username);

                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }



        #endregion



        #region les fonction de selections



        public static Joueurs GetJoueur(Int64 idjo)
        {
            //le c yon objet nap inisyalizel a nul
            Joueurs resultat = null;
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Joueurs where IdJoueurs=@jo";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;
                cmd.Parameters.AddWithValue("@jo", idjo);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Joueurs c = new Joueurs();
                    c.NomComplet = rd.GetString(0);
                    c.Sexe = rd.GetString(1);
                    c.Dateajout = rd.GetDateTime(2);
                    c.UserName = rd.GetString(3);
                    //nou afekte c a resultat
                    resultat = c;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }


        #region
        #endregion



        public static BindingList<Joueurs> GetJoueurs()
        {
            BindingList<Joueurs> resultat = new BindingList<Joueurs>();
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Joueurs order by DateAjout desc ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Joueurs c = new Joueurs();
                    c.NomComplet = rd.GetString(0);
                    c.Sexe = rd.GetString(1);
                    c.Dateajout = rd.GetDateTime(2);
                    c.UserName = rd.GetString(3);
                    //nou ajoute c nan resultat
                    resultat.Add(c);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }


        #region
        #endregion


        public static BindingList<Joueurs> GetJoueurs(Int64 critere)
        {
            BindingList<Joueurs> resultat = new BindingList<Joueurs>();
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Joueurs where IdJoueurs like @critere ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;
                cmd.Parameters.AddWithValue("@critere", "%" + critere + "%");
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Joueurs c = new Joueurs();
                    c.NomComplet = rd.GetString(0);
                    c.Sexe = rd.GetString(1);
                    c.Dateajout = rd.GetDateTime(2);
                    c.UserName = rd.GetString(3);
                    //nou ajoute c nan resultat
                    resultat.Add(c);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }
       
        
        
        #region
        #endregion




        public static int GetJoueurNb()
        {
            //le c yon objet nap inisyalizel a nul
            int resultat = 0;
            SqlConnection con = null;
            SqlCommand cmd = null;

            string req = "select count(*) from Joueurs";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;
                // conveti objet executeScalar en entier
                resultat = (int)cmd.ExecuteScalar();


            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }



        #endregion




    }
}
