﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
// importer projet modele
using Modele;

namespace Controleur
{
    public class BouleControleur
    {
        static string chcon = "Data Source=.;Initial Catalog=BDBoletoKlik;Integrated Security=True";

        public static int Add(Int64 Id, Int64 idjoueurs, Int64 idjeux,int numero, decimal prix, DateTime Datemise)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "insert into Boules (Id,IdJoeur,IdJeu,Numero,Prix) values (@id,@idj,@jw,@Nu,@Mo)";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Boule Bo = new Boule();
                Bo.ID = Id;
                Bo.idjoeur = idjoueurs;
                Bo.idjeux = idjeux;
                Bo.numero = numero;
                Bo.prix = prix;
                Bo.datemise = Datemise;
                //definir les parametres
                cmd.Parameters.AddWithValue("@id", Bo.ID);
                cmd.Parameters.AddWithValue("@idj", Bo.idjoeur);
                cmd.Parameters.AddWithValue("@jw", Bo.idjeux);
                cmd.Parameters.AddWithValue("@Nu", Bo.numero);
                cmd.Parameters.AddWithValue("@Mo", Bo.prix);
                cmd.Parameters.AddWithValue("@Da", Bo.datemise);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;

        }


        public static BindingList<Boule> GetBoules(Int64 idjo, Int64 idjeu)
        {
            BindingList<Boule> resultat = new BindingList<Boule>();
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Boules where IdJoeur='"+idjo+"' and IdJeu='"+idjeu+"' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Boule c = new Boule();
                    c.numero = rd.GetInt32(3);
                    c.prix = rd.GetDecimal(4);
                    //nou ajoute c nan resultat
                    resultat.Add(c);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static int GetBouleGagnantes(int numero,Int64 idjo)
        {
            int resultat =0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Boules where Numero='" +numero+ "'and IdJoueur='"+idjo+"' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Boule c = new Boule();
                    c.numero = rd.GetInt32(3);
                    //nou ajoute c nan resultat
                    resultat=c.numero;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static decimal GetPrixBouleGagnantes(int numero,Int64 idjo)
        {
            decimal resultat = 0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Boules where Numero='" + numero + "' and IdJoueur='" + idjo + "' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Boule c = new Boule();
                    c.prix = rd.GetDecimal(4);
                    //nou ajoute c nan resultat
                    resultat = c.prix;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }


        //public static int ModifierBoule(Int64 idJoueur, decimal prix, DateTime datemodification)
        //{
        //    //nap gen yon varyab kap tounen menm tip avek fonksyon an
        //    //si c yon antye inisyalizel a zero
        //    SqlConnection con = null;
        //    SqlCommand cmd = null;
        //    string req = "update Boules set prix=@mont,DateModification=@dat where IdJoueur=@idj";
        //    int resultat = 0;
        //    try
        //    {
        //        con = new SqlConnection(chcon);
        //        con.Open();
        //        cmd = con.CreateCommand();
        //        //requette a executee
        //        cmd.CommandText = req;
        //        //creation de l'objet modele
        //        Boule co = new Boule();
        //        co.idjoeur = idJoueur;
        //        co.prix = prix;
        //        co.dateModification = datemodification;
        //        //definir les parametres
        //        cmd.Parameters.AddWithValue("@idj", co.idjoeur);
        //        cmd.Parameters.AddWithValue("@mont", co.prix);
        //        cmd.Parameters.AddWithValue("@dat", co.dateModification);
        //        //executer requette
        //        resultat = cmd.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        //        throw ex;
        //    }
        //    finally
        //    {
        //        //pour fermer les connection
        //        if (con != null)
        //        {
        //            con.Close();
        //        }
        //    }
        //    return resultat;
        //}


        //public static decimal Getprix(Int64 Critere)
        //{
        //    Decimal resultat = 0;
        //    //si c yon lis wap inisyalizel a lis vid
        //    SqlConnection con = null;
        //    SqlCommand cmd = null;
        //    SqlDataReader rd = null;
        //    string req = "select * from Boules where IdJoueur='" + Critere + "' ";
        //    try
        //    {
        //        con = new SqlConnection(chcon);
        //        con.Open();
        //        cmd = con.CreateCommand();
        //        cmd.CommandText = req;

        //        rd = cmd.ExecuteReader();
        //        while (rd.Read())
        //        {
        //            //deklare yon obje domaine de sa nap rekipere a
        //            Boule c = new Boule();
        //            c.prix = rd.GetDecimal(2);
        //            //nou ajoute c nan resultat
        //            resultat = c.prix;
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con != null)
        //        {
        //            con.Close();
        //        }
        //    }
        //    return resultat;
        //}
    }
}
