﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
// importer projet modele
using Modele;

namespace Controleur
{
    public class JeuxControleur
    {

        static string chcon = "Data Source=.;Initial Catalog=BDBoletoKlik;Integrated Security=True";
        //toutes les methodes de modification doivent retourner un entier
        #region les fonction de modifications
        public static int Add(Int64 Id, string Description, DateTime DateJeu, Int32 Lot1, Int32 Lot2, Int32 Lot3, bool Estactif)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "insert into Jeux (Id,Description,DateJeu,Lot1,Lot2,Lot3,Estactif) values (@id,@des,@Dat,@l1,@l2,@l3,@act)";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Jeux je = new Jeux();
                je.ID = Id;
                je.description = Description;
                je.datejeu = DateJeu;
                je.Lot1 = Lot1;
                je.Lot2 = Lot2;
                je.Lot3 = Lot3;
                je.estactif = Estactif;
                //definir les parametres
                cmd.Parameters.AddWithValue("@id", je.ID);
                cmd.Parameters.AddWithValue("@des", je.description);
                cmd.Parameters.AddWithValue("@Dat", je.datejeu);
                cmd.Parameters.AddWithValue("@l1", je.Lot1);
                cmd.Parameters.AddWithValue("@l2", je.Lot2);
                cmd.Parameters.AddWithValue("@l3", je.Lot3);
                cmd.Parameters.AddWithValue("@act", je.estactif);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static int ModifierJeux()
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "update Jeux set Estactif='False' where Estactif='True'";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele

                //definir les parametres
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //        throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        #endregion


        public static bool GetEtat()
        {
            bool resultat = false;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Jeux where Estactif='True' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Jeux c = new Jeux();
                    c.estactif = rd.GetBoolean(6);
                    //nou ajoute c nan resultat
                    resultat = c.estactif;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static int GetLot1()
        {
            int resultat = 0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Jeux where EstActif='True' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Jeux c = new Jeux();
                    c.Lot1 = rd.GetInt32(3);
                    //nou ajoute c nan resultat
                    resultat=c.Lot1;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static int GetLot2()
        {
            int resultat = 0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Jeux where EstActif='True' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Jeux c = new Jeux();
                    c.Lot2 = rd.GetInt32(4);
                    //nou ajoute c nan resultat
                    resultat = c.Lot2;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }

        public static int GetLot3()
        {
            int resultat = 0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Jeux where EstActif='True' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Jeux c = new Jeux();
                    c.Lot3 = rd.GetInt32(5);
                    //nou ajoute c nan resultat
                    resultat = c.Lot3;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }
    }
}