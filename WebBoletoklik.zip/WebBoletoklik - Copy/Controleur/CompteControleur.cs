﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
// importer projet modele
using Modele;

namespace Controleur
{
    public class CompteControleur
    {
        static string chcon = "Data Source=.;Initial Catalog=BDBoletoKlik;Integrated Security=True";

        public static int RenflouerCompte(Int64 Id, Int64 idjoueurs, decimal montant, DateTime datemodification)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "insert into Comptes (Id,IdJoueur,Montant,DateModification) values (@id,@idj,@Mo,@Da)";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Compte co = new Compte();
                co.ID = Id;
                co.idjoeur = idjoueurs;
                co.montant = montant;
                co.dateModification = datemodification;
                //definir les parametres
                cmd.Parameters.AddWithValue("@id", co.ID);
                cmd.Parameters.AddWithValue("@idj", co.idjoeur);
                cmd.Parameters.AddWithValue("@Mo", co.montant);
                cmd.Parameters.AddWithValue("@Da", co.dateModification);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;

        }


        public static int ModifierCompte(Int64 idJoueur, decimal montant, DateTime datemodification)
        {
            //nap gen yon varyab kap tounen menm tip avek fonksyon an
            //si c yon antye inisyalizel a zero
            SqlConnection con = null;
            SqlCommand cmd = null;
            string req = "update Comptes set Montant=@mont,DateModification=@dat where IdJoueur=@idj";
            int resultat = 0;
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                //requette a executee
                cmd.CommandText = req;
                //creation de l'objet modele
                Compte co = new Compte();
                co.idjoeur = idJoueur;
                co.montant = montant;
                co.dateModification = datemodification;
                //definir les parametres
                cmd.Parameters.AddWithValue("@idj", co.idjoeur);
                cmd.Parameters.AddWithValue("@mont", co.montant);
                cmd.Parameters.AddWithValue("@dat", co.dateModification);
                //executer requette
                resultat = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //        throw ex;
            }
            finally
            {
                //pour fermer les connection
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }


        public static decimal GetMontant(Int64 Critere)
        {
            Decimal resultat = 0;
            //si c yon lis wap inisyalizel a lis vid
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader rd = null;
            string req = "select * from Comptes where IdJoueur='"+Critere+"' ";
            try
            {
                con = new SqlConnection(chcon);
                con.Open();
                cmd = con.CreateCommand();
                cmd.CommandText = req;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    //deklare yon obje domaine de sa nap rekipere a
                    Compte c = new Compte();
                    c.montant = rd.GetDecimal(2);
                    //nou ajoute c nan resultat
                    resultat=c.montant;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
            return resultat;
        }
    }
}
