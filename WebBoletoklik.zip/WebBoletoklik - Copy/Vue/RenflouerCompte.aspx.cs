﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Controleur;
namespace Vue
{
    public partial class RenflouerCompte : System.Web.UI.Page
    {


        protected void btnrenflouer_Click(object sender, EventArgs e)
        {
            Int64 IdJoeur;
            decimal Montant;
            DateTime DateModification = System.DateTime.Now;
            decimal NouveauMontant;
            decimal montanttotal;
            int resultat = 0;

            try
            {
                string idjo = txtIdjoueur.Text.Trim();
                IdJoeur = Int64.Parse(idjo);
                string mont = txtmontant.Text.Trim();
                NouveauMontant = decimal.Parse(mont);

                Montant = CompteControleur.GetMontant(IdJoeur);

                montanttotal = Montant+NouveauMontant;

                resultat = CompteControleur.ModifierCompte(IdJoeur, montanttotal, DateModification);
                lblmessage.Text = "Le compte a ete renfloue";
                txtIdjoueur.Text = "";
                txtmontant.Text = "";

            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
            }
        }

        protected void btnpayer_Click(object sender, EventArgs e)
        {
            Int64 IdJoeur;
            decimal Montant;
            DateTime DateModification = System.DateTime.Now;
            decimal NouveauMontant;
            decimal montanttotal;
            int resultat = 0;

            try
            {
                string idjo = txtIdjoueur.Text.Trim();
                IdJoeur = Int64.Parse(idjo);
                string mont = txtmontant.Text.Trim();
                NouveauMontant = decimal.Parse(mont);

                Montant = CompteControleur.GetMontant(IdJoeur);

                montanttotal = Montant - NouveauMontant;
                if (montanttotal < 100)
                {
                    lblmessage.Text = "Votre solde ne doit pas etre inferieur a 100 Gourdes";
                }
                else
                {

                    resultat = CompteControleur.ModifierCompte(IdJoeur, montanttotal, DateModification);

                    lblmessage.Text = "Paiment Effectue";
                    txtIdjoueur.Text = "";
                    txtmontant.Text = "";
                }

            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
            }
        }
    }
}