﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Controleur;

namespace Vue
{
    public partial class JouerBoule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnjouer_Click(object sender, EventArgs e)
        {
            Random var = new Random();
            Int64 Id = var.Next(1, 99999);
            string boule;
            int boul;
            string mont;
            decimal montant;
            int result = 0;
            try
            {
                boule = cmbboule.SelectedItem.Text;
                boul = int.Parse(boule);
                mont = txtmontant.Text;
                montant = decimal.Parse(mont);

                result = BouleControleur.Add(Id, 12, 46799, boul, montant, System.DateTime.Now);

                if (result > 0)
                {
                    gdvboule.DataSource = BouleControleur.GetBoules(12, 46799);
                    gdvboule.DataBind();
                }

            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;

            }
        }
    }
}