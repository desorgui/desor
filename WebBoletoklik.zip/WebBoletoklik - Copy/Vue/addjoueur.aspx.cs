﻿using Controleur;
using Modele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Modele;

namespace Vue
{
    public partial class addjoueur : System.Web.UI.Page
    {
        public Joueurs Jo;
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnEnregister_Click(object sender, EventArgs e)
        {
            string Id;
            string Nomcomplet;
            string sexe;
            string username;
            DateTime dateaj = System.DateTime.Now;
            int resultat = 0;
            int result = 0;
            Random var= new Random();
            Int64 idcompte=var.Next(1,99999);
            try
            {
                Id = txtId.Text.Trim();
                Int64 idjou = int.Parse(Id);
                Nomcomplet = txtnomcomplet.Text.Trim();
                sexe = cmbSexe.SelectedItem.Value;
                username = txtusername.Text.Trim();
                resultat = JoueurControleur.Add(idjou, Nomcomplet, sexe, dateaj, username);
                result = CompteControleur.RenflouerCompte(idcompte, idjou, 0, dateaj);
            }
            catch (Exception ex)
            {
                lblmessage.Text = ex.Message;
            }
        }
    }
}