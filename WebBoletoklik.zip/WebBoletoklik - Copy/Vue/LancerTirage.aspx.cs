﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Controleur;
namespace Vue
{
    public partial class RenflouerCompte : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btntirage_Click(object sender, EventArgs e)
        {
            //Int64 Id = 14;
            //Int64 IdJoeur = 12;
            //Int64 IdJeux = 44625;
            //DateTime DateGain = System.DateTime.Now;
            //int result = 0;
            //decimal MontantLot1;
            //decimal MontantLot2;
            //decimal MontantLot3;
            //decimal MontantTotal;
            //int Lot1 = JeuxControleur.GetLot1();
            //int Lot2 = JeuxControleur.GetLot2();
            //int Lot3 = JeuxControleur.GetLot3();
            //int BoulegagnanteLot1 = BouleControleur.GetBouleGagnantes(Lot1, IdJoeur);
            //int BoulegagnanteLot2 = BouleControleur.GetBouleGagnantes(Lot2, IdJoeur);
            //int BoulegagnanteLot3 = BouleControleur.GetBouleGagnantes(Lot3, IdJoeur);
            //decimal PrixBoulegagnanteLot1 = BouleControleur.GetPrixBouleGagnantes(Lot1, IdJoeur);
            //decimal PrixBoulegagnanteLot2 = BouleControleur.GetPrixBouleGagnantes(Lot2, IdJoeur);
            //decimal PrixBoulegagnanteLot3 = BouleControleur.GetPrixBouleGagnantes(Lot3, IdJoeur);
            try
            {

                //if (BoulegagnanteLot1 != null)
                //{
                //    MontantLot1 = PrixBoulegagnanteLot1 * 50;

                //    if (BoulegagnanteLot2 != null)
                //    {
                //        MontantLot2 = PrixBoulegagnanteLot2 * 20;

                //        if (BoulegagnanteLot3 != null)
                //        {
                //            MontantLot3 = PrixBoulegagnanteLot3 * 10;

                //            MontantTotal = MontantLot1 + MontantLot2 + MontantLot3;
                //            result = GagnantControleur.Add(Id, IdJoeur, IdJeux, MontantTotal, DateGain);

                //        }
                //    }
                //}
            
            JeuxControleur.ModifierJeux();
            }
        catch(Exception ex){
            lblmessage.Text = ex.Message;

        }
            
        }
    }
}