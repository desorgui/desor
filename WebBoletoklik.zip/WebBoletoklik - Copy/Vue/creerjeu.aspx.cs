﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Controleur;

namespace Vue
{
    public partial class creerjeu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btncree_Click(object sender, EventArgs e)
        {
             
        string Description;
        Random var = new Random();
        Int64 Id=var.Next(0,99999);
          DateTime DateJeux=System.DateTime.Now;
          Int32 lot1 = var.Next(0, 99); ;
          Int32 lot2 = var.Next(0, 99); ;
          Int32 lot3 = var.Next(0, 99); ;
           Boolean Estactif = true;
           int resultat = 0;
            bool rere=true;

           txtId.Text = "" + Id;
           Description = cmbDescription.SelectedItem.Text;
           txtlot1.Text = "" + lot1;
           txtlot2.Text = "" + lot2;
           txtlot3.Text = "" + lot3;
            rere=JeuxControleur.GetEtat();
            if (rere == true)
            {
                lblmessage.Text = "Il y a deja un Jeu actif";
            }
            else
            {
                resultat = JeuxControleur.Add(Id, Description, DateJeux, lot1, lot2, lot3, Estactif);

            }
        }

      
    }
}